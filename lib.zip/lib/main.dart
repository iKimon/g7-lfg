import 'package:flutter/material.dart';
import 'login.dart';
import 'home2.dart';
import 'dart:async';
import 'package:map_view/map_view.dart';

void main(){
  MapView.setApiKey(API_KEY);
  runApp(new MaterialApp(
    title: 'GroupSeven',
    home: new Login(),
  ));
}



