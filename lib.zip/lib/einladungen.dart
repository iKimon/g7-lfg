import 'package:flutter/material.dart';
import 'home2.dart';

class Einladung extends StatefulWidget {
  @override
  _Einladung createState() => new _Einladung();
}

class _Einladung extends State<Einladung>{
  @override
  Widget build(BuildContext context) {

    return new Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.red[800],
      ),
      body: new Center(
        child: new Container(
          child: new Column(
            children: <Widget>[
              new (

              ),
            ],
          ),
        ),
      ),
    );
  }
}