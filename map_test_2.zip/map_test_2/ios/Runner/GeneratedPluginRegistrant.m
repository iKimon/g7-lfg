//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <map_view/MapViewPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [MapViewPlugin registerWithRegistrar:[registry registrarForPlugin:@"MapViewPlugin"]];
}

@end
